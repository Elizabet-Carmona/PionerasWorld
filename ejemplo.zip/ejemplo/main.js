// la cosa de eli
var $avatar = document.getElementById('avatar');

function cambiarOrejas(element) {
    console.log('voy a cambiar');
    document.getElementById('avatar').setAttribute('orejas' , element.value);
    console.log('cambie');
}

function cambiarCabeza(element) {
    console.log('voy a cambiar');
    document.getElementById('avatar').setAttribute('cabeza' , element.value);
    console.log('cambie');
}